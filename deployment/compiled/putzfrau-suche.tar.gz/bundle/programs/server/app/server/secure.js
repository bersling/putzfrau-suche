(function(){Meteor.startup(function () {
    process.env.MAIL_URL = 'smtp://bersling:lampsaregood4light.@smtp.sendgrid.net:587';
});
}).call(this);

//# sourceMappingURL=secure.js.map
