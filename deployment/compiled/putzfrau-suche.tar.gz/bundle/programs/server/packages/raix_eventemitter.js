(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

/* Package-scope variables */
var EventEmitter;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/raix_eventemitter/packages/raix_eventemitter.js               //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/raix:eventemitter/eventemitter.server.js                 //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
/* global EventEmitter: true */                                      // 1
EventEmitter = Npm.require('events').EventEmitter;                   // 2
                                                                     // 3
///////////////////////////////////////////////////////////////////////   // 12
                                                                          // 13
}).call(this);                                                            // 14
                                                                          // 15
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['raix:eventemitter'] = {
  EventEmitter: EventEmitter
};

})();

//# sourceMappingURL=raix_eventemitter.js.map
