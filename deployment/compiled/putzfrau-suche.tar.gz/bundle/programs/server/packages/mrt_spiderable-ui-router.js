(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;

/* Package-scope variables */
var Spiderable;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt_spiderable-ui-router/packages/mrt_spiderable-ui-router.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
(function () {                                                                                                        // 1
                                                                                                                      // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/mrt:spiderable-ui-router/spiderable.js                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var fs = Npm.require('fs');                                                                                        // 1
var child_process = Npm.require('child_process');                                                                  // 2
var querystring = Npm.require('querystring');                                                                      // 3
var urlParser = Npm.require('url');                                                                                // 4
                                                                                                                   // 5
Spiderable = {};                                                                                                   // 6
                                                                                                                   // 7
// list of bot user agents that we want to serve statically, but do                                                // 8
// not obey the _escaped_fragment_ protocol. The page is served                                                    // 9
// statically to any client whos user agent matches any of these                                                   // 10
// regexps. Users may modify this array.                                                                           // 11
//                                                                                                                 // 12
// An original goal with the spiderable package was to avoid doing                                                 // 13
// user-agent based tests. But the reality is not enough bots support                                              // 14
// the _escaped_fragment_ protocol, so we need to hardcode a list                                                  // 15
// here. I shed a silent tear.                                                                                     // 16
Spiderable.userAgentRegExps = [                                                                                    // 17
    /^facebookexternalhit/i, /^linkedinbot/i, /^twitterbot/i];                                                     // 18
                                                                                                                   // 19
// how long to let phantomjs run before we kill it                                                                 // 20
var REQUEST_TIMEOUT = 15*1000;                                                                                     // 21
// maximum size of result HTML. node's default is 200k which is too                                                // 22
// small for our docs.                                                                                             // 23
var MAX_BUFFER = 5*1024*1024; // 5MB                                                                               // 24
                                                                                                                   // 25
WebApp.connectHandlers.use(function (req, res, next) {                                                             // 26
  if (/\?.*_escaped_fragment_=/.test(req.url) ||                                                                   // 27
      _.any(Spiderable.userAgentRegExps, function (re) {                                                           // 28
        return re.test(req.headers['user-agent']); })) {                                                           // 29
                                                                                                                   // 30
    // reassembling url without escaped fragment if exists                                                         // 31
    var parsedUrl = urlParser.parse(req.url);                                                                      // 32
    var parsedQuery = querystring.parse(parsedUrl.query);                                                          // 33
    delete parsedQuery['_escaped_fragment_'];                                                                      // 34
    var newQuery = querystring.stringify(parsedQuery);                                                             // 35
    var newPath = parsedUrl.pathname + (newQuery ? ('?' + newQuery) : '');                                         // 36
    var url = "http://" + req.headers.host + newPath;                                                              // 37
                                                                                                                   // 38
    // This string is going to be put into a bash script, so it's important                                        // 39
    // that 'url' (which comes from the network) can neither exploit phantomjs                                     // 40
    // or the bash script. JSON stringification should prevent it from                                             // 41
    // exploiting phantomjs, and since the output of JSON.stringify shouldn't                                      // 42
    // be able to contain newlines, it should be unable to exploit bash as                                         // 43
    // well.                                                                                                       // 44
    var phantomScript = "var url = " + JSON.stringify(url) + ";" +                                                 // 45
          "var page = require('webpage').create();" +                                                              // 46
          "page.open(url);" +                                                                                      // 47
          "setInterval(function() {" +                                                                             // 48
          "  var ready = page.evaluate(function () {" +                                                            // 49
          "    if (typeof Meteor !== 'undefined' " +                                                               // 50
          "        && typeof(Meteor.status) !== 'undefined' " +                                                    // 51
          "        && typeof(window.__ui_router_dom_ready__) !== 'undefined' " +                                   // 52
          "        && Meteor.status().connected) {" +                                                              // 53
          "      Deps.flush();" +                                                                                  // 54
          "      return DDP._allSubscriptionsReady();" +                                                           // 55
          "    }" +                                                                                                // 56
          "    return false;" +                                                                                    // 57
          "  });" +                                                                                                // 58
          "  if (ready) {" +                                                                                       // 59
          "    var out = page.content;" +                                                                          // 60
          "    out = out.replace(/<script[^>]+>(.|\\n|\\r)*?<\\/script\\s*>/ig, '');" +                            // 61
          "    out = out.replace('<meta name=\"fragment\" content=\"!\">', '');" +                                 // 62
          "    console.log(out);" +                                                                                // 63
          "    phantom.exit();" +                                                                                  // 64
          "  }" +                                                                                                  // 65
          "}, 100);\n";                                                                                            // 66
                                                                                                                   // 67
    // Run phantomjs.                                                                                              // 68
    //                                                                                                             // 69
    // Use '/dev/stdin' to avoid writing to a temporary file. We can't                                             // 70
    // just omit the file, as PhantomJS takes that to mean 'use a                                                  // 71
    // REPL' and exits as soon as stdin closes.                                                                    // 72
    //                                                                                                             // 73
    // However, Node 0.8 broke the ability to open /dev/stdin in the                                               // 74
    // subprocess, so we can't just write our string to the process's stdin                                        // 75
    // directly; see https://gist.github.com/3751746 for the gory details. We                                      // 76
    // work around this with a bash heredoc. (We previous used a "cat |"                                           // 77
    // instead, but that meant we couldn't use exec and had to manage several                                      // 78
    // processes.)                                                                                                 // 79
    child_process.execFile(                                                                                        // 80
      '/bin/bash',                                                                                                 // 81
      ['-c',                                                                                                       // 82
       ("exec phantomjs --load-images=no /dev/stdin <<'END'\n" +                                                   // 83
        phantomScript + "END\n")],                                                                                 // 84
      {timeout: REQUEST_TIMEOUT, maxBuffer: MAX_BUFFER},                                                           // 85
      function (error, stdout, stderr) {                                                                           // 86
        if (!error && /<html/i.test(stdout)) {                                                                     // 87
          res.writeHead(200, {'Content-Type': 'text/html; charset=UTF-8'});                                        // 88
          res.end(stdout);                                                                                         // 89
        } else {                                                                                                   // 90
          // phantomjs failed. Don't send the error, instead send the                                              // 91
          // normal page.                                                                                          // 92
          if (error && error.code === 127)                                                                         // 93
            Meteor._debug("spiderable: phantomjs not installed. Download and install from http://phantomjs.org/"); // 94
          else                                                                                                     // 95
            Meteor._debug("spiderable: phantomjs failed:", error, "\nstderr:", stderr);                            // 96
                                                                                                                   // 97
          next();                                                                                                  // 98
        }                                                                                                          // 99
      });                                                                                                          // 100
  } else {                                                                                                         // 101
    next();                                                                                                        // 102
  }                                                                                                                // 103
});                                                                                                                // 104
                                                                                                                   // 105
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      // 115
}).call(this);                                                                                                        // 116
                                                                                                                      // 117
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:spiderable-ui-router'] = {
  Spiderable: Spiderable
};

})();

//# sourceMappingURL=mrt_spiderable-ui-router.js.map
