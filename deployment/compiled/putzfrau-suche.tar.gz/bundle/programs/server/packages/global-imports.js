/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Date = Package['es5-shim'].Date;
parseInt = Package['es5-shim'].parseInt;
gm = Package['cfs:graphicsmagick'].gm;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
Kadira = Package['meteorhacks:kadira'].Kadira;
Spiderable = Package['mrt:spiderable-ui-router'].Spiderable;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
FS = Package['cfs:base-package'].FS;
Autoupdate = Package.autoupdate.Autoupdate;

